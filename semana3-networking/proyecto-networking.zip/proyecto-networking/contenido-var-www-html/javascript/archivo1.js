// Tiene que devolver un archivo JavaScript cualquiera (os inventais su contenido) en http://0.0.0.0/javascript/archivo1.js

alert("Hola! Soy un archivo js.");
console.log("Hello World!")